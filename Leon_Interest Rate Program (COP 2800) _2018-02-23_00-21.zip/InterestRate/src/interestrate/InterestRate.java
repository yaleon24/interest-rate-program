/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
Write a program that takes two numbers from the Java console representing, respectively, an investment and an interest rate (you will expect the user to enter a number such as .065 for the interest rate, representing a 6.5% interest rate.)

Do not prompt anything from the user before reading in the investment and interest rate.

Your program should calculate and output (in $ notation) the future value of the investment in 5, 10, 15 and 20 years using the following formula:

future value = investment * (1 + interest rate)^year

We will assume the interest rate is an annual rate and is compounded annually.

Use NumberFormat to output the $:

https://docs.oracle.com/javase/7/docs/api/javax/swing/text/NumberFormatter.html

Only display the output like this:

Year 5: $31,907.04
Year 10: $40,722.37
Year 15: $51,973.20
Year 20: $66,332.44

substituting the correct amount for the value of the investment after the given period.

The program must ignore any input other than decimal numbers.

Scanner s = new Scanner(System.in);

while(!s.hasNextDouble()) s.next();

Lastly, don't forget to take out the package when you submit to mimir.

Pay attention to the spacing in the output.
 */
//package interestrate;

import java.util.Scanner;
import javax.swing.text.NumberFormatter;
import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author dfreer
 */
public class InterestRate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
        Scanner s = new Scanner(System.in);
  
        //fill in the logic here
        while(!s.hasNextDouble()) s.next();
        double invest=s.nextDouble();
        while(!s.hasNextDouble()) s.next();
        double interrest=s.nextDouble();
        
        for(int years=5;years<=20;years+=5){
        double value=((1+interrest));
               value= invest*(Math.pow(value, years));
               System.out.println("Year " +years + ": " + nf.format(value));
        }
        //Display like this exactly
            
        
    }
    
}
